import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper

def Message processData(Message message) {
    
    def messageBody = message.getBody(java.lang.String) as String
    def messageObj = new JsonSlurper().parseText(messageBody)
    def eventType = messageObj.type
    message.setProperty('EventType',eventType)
    
    return message;
}