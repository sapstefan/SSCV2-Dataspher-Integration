import com.sap.it.api.mapping.*;

def void mergeToArray(String[] inputArray, Output output, MappingContext context) {
    def outputString = "ARRAY("
    for(int i=0; i<inputArray.size(); i++)
    {
        if (i!=0)
        {
            outputString +=  ","
        }
        outputString += "'" + inputArray[i] + "'"
    }
    outputString += ")"
    output.addValue(outputString)
}
